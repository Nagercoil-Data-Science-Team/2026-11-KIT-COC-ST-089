"""
Module 9: Content-Based Recommendation (CBR) System
Recommends relevant instructional sports videos tailored to detected athlete weaknesses.
Evaluated using actual expert relevance annotations from SportSkills visual feedback benchmark.
"""

import numpy as np
import logging
from sklearn.metrics.pairwise import cosine_similarity

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class ContentBasedRecommender:
    """
    Content-Based Recommender matching athlete movement weakness profiles
    against reference instructional video feature vectors.
    """

    def __init__(self, instructional_catalog=None):
        """
        instructional_catalog: dict of {clip_id: {"features": np.array, "metadata": dict}}
        """
        self.catalog = instructional_catalog or {}
        self.clip_ids = list(self.catalog.keys())
        if self.catalog:
            self.feature_matrix = np.array([self.catalog[cid]["features"] for cid in self.clip_ids])
        else:
            self.feature_matrix = None

    def register_catalog(self, catalog_dict):
        """
        Register or update the instructional video repository.
        """
        self.catalog = catalog_dict
        self.clip_ids = list(self.catalog.keys())
        self.feature_matrix = np.array([self.catalog[cid]["features"] for cid in self.clip_ids])
        logger.info(f"Registered {len(self.clip_ids)} instructional video clips in recommendation catalog.")

    def recommend(self, query_weakness_vector, top_k=5, filter_sport=None):
        """
        Retrieves top_k instructional video candidates ranked by cosine similarity.
        Args:
            query_weakness_vector: (D,) numpy array representing athlete weakness & kinematics
            top_k: integer
            filter_sport: optional string to filter candidate videos by sport
        Returns:
            ranked_recommendations: list of dicts with ranked clips and scores
        """
        if self.feature_matrix is None or len(self.clip_ids) == 0:
            return []
            
        q_vec = query_weakness_vector.reshape(1, -1)
        sim_scores = cosine_similarity(q_vec, self.feature_matrix)[0]
        
        # Sort descending
        sorted_indices = np.argsort(-sim_scores)
        
        results = []
        for idx in sorted_indices:
            cid = self.clip_ids[idx]
            clip_meta = self.catalog[cid].get("metadata", {})
            if filter_sport and clip_meta.get("sport", "").lower() != filter_sport.lower():
                continue
                
            results.append({
                "clip_id": cid,
                "similarity_score": round(float(sim_scores[idx]), 4),
                "sport": clip_meta.get("sport", "General"),
                "title": clip_meta.get("title", f"Instructional Drill {cid}"),
                "coaching_focus": clip_meta.get("focus", "Technique correction"),
                "drill_type": clip_meta.get("drill_type", "Standard practice")
            })
            
            if len(results) >= top_k:
                break
                
        return results

