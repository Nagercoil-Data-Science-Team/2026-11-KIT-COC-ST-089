"""
Module 7: Sports Skill Classifier & Multi-Task Action Evaluation Model
Trains on multi-modal fused representations to classify sports skills and execution validity.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from Sports_Skill_Evaluation.models.pg_cmaf import PGCMAFLayer, MultiModalFusionComparison


class SportsSkillClassificationModel(nn.Module):
    """
    Multi-Task Sports Skill Classifier:
    1. Sports Category Classification (e.g., 6 sports classes)
    2. Skill Execution Quality / Mastery Assessment (Positive vs. Negative demonstration)
    """

    def __init__(self, visual_dim=768, pose_dim=59, fusion_dim=256, num_classes=6, fusion_mode="pg_cmaf"):
        super(SportsSkillClassificationModel, self).__init__()
        self.fusion_mode = fusion_mode
        self.num_classes = num_classes
        
        # Multi-modal fusion backbone
        self.fusion_module = MultiModalFusionComparison(
            visual_dim=visual_dim,
            pose_dim=pose_dim,
            fusion_dim=fusion_dim,
            mode=fusion_mode
        )
        
        # Temporal pooling / sequence encoder if 3D tensor
        self.temporal_gru = nn.GRU(
            input_size=fusion_dim,
            hidden_size=fusion_dim // 2,
            num_layers=1,
            batch_first=True,
            bidirectional=True
        )
        
        # Classification Head (Sports Category)
        self.classifier_head = nn.Sequential(
            nn.Linear(fusion_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )
        
        # Skill Quality Head (Binary: 1=Correct/Mastered, 0=Improper Execution)
        self.quality_head = nn.Sequential(
            nn.Linear(fusion_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 2)
        )

    def forward(self, visual_feats, pose_feats):
        """
        Args:
            visual_feats: (B, visual_dim) or (B, T, visual_dim)
            pose_feats: (B, pose_dim) or (B, T, pose_dim)
        Returns:
            category_logits: (B, num_classes)
            quality_logits: (B, 2)
            fused_rep: (B, fusion_dim)
            attn_weights: Attention maps from PG-CMAF (if applicable)
        """
        fused, attn_weights, gate = self.fusion_module(visual_feats, pose_feats)
        
        # Handle temporal sequence vs pooled vector
        if fused.dim() == 3:
            gru_out, _ = self.temporal_gru(fused)
            # Pool over temporal dimension
            pooled_rep = gru_out.mean(dim=1)
        else:
            pooled_rep = fused
            
        category_logits = self.classifier_head(pooled_rep)
        quality_logits = self.quality_head(pooled_rep)
        
        return category_logits, quality_logits, pooled_rep, attn_weights

