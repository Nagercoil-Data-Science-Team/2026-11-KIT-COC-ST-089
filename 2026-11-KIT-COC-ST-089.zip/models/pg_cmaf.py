"""
Module 5: Pose-Guided Cross-Modal Attention Fusion (PG-CMAF) Layer
Proposed Novel Architecture for Multi-Modal Sports Skill Evaluation.
Integrates RTMPose skeletal kinematics with VideoMAE spatiotemporal representations.
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class PoseGuidedCrossModalAttention(nn.Module):
    """
    Pose-Guided Multi-Head Cross-Modal Attention Core.
    Skeletal pose representations generate queries that attend over visual representations.
    """

    def __init__(self, d_model=256, n_heads=4, dropout=0.1):
        super(PoseGuidedCrossModalAttention, self).__init__()
        assert d_model % n_heads == 0, "d_model must be divisible by n_heads"
        
        self.d_model = d_model
        self.n_heads = n_heads
        self.d_k = d_model // n_heads
        
        self.q_proj = nn.Linear(d_model, d_model)  # Pose Queries
        self.k_proj = nn.Linear(d_model, d_model)  # Visual Keys
        self.v_proj = nn.Linear(d_model, d_model)  # Visual Values
        self.out_proj = nn.Linear(d_model, d_model)
        
        self.dropout = nn.Dropout(dropout)

    def forward(self, pose_feat, visual_feat):
        """
        Args:
            pose_feat: (B, T_p, D) or (B, D)
            visual_feat: (B, T_v, D) or (B, D)
        Returns:
            attn_output: (B, T_p, D)
            attn_weights: (B, n_heads, T_p, T_v)
        """
        # Ensure 3D tensors: (B, T, D)
        is_2d_pose = False
        if pose_feat.dim() == 2:
            is_2d_pose = True
            pose_feat = pose_feat.unsqueeze(1)
            
        if visual_feat.dim() == 2:
            visual_feat = visual_feat.unsqueeze(1)
            
        B, T_p, _ = pose_feat.shape
        _, T_v, _ = visual_feat.shape
        
        # 1. Project Queries from Pose, Keys and Values from Visual
        Q = self.q_proj(pose_feat).view(B, T_p, self.n_heads, self.d_k).transpose(1, 2)  # (B, H, T_p, d_k)
        K = self.k_proj(visual_feat).view(B, T_v, self.n_heads, self.d_k).transpose(1, 2)  # (B, H, T_v, d_k)
        V = self.v_proj(visual_feat).view(B, T_v, self.n_heads, self.d_k).transpose(1, 2)  # (B, H, T_v, d_k)
        
        # 2. Scaled Dot-Product Attention: Pose queries attending to visual features
        scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)  # (B, H, T_p, T_v)
        attn_weights = F.softmax(scores, dim=-1)
        attn_weights_drop = self.dropout(attn_weights)
        
        # 3. Weighted Visual Aggregation guided by Pose
        context = torch.matmul(attn_weights_drop, V)  # (B, H, T_p, d_k)
        context = context.transpose(1, 2).contiguous().view(B, T_p, self.d_model)  # (B, T_p, D)
        
        output = self.out_proj(context)
        
        if is_2d_pose:
            output = output.squeeze(1)
            
        return output, attn_weights


class PGCMAFLayer(nn.Module):
    """
    Complete Pose-Guided Cross-Modal Attention Fusion (PG-CMAF) Architecture.
    Includes:
        1. Visual Feature Projection (Linear + GELU)
        2. Skeletal Feature Projection (Linear + GELU)
        3. Pose-Guided Cross-Modal Multi-Head Attention
        4. Adaptive Gating Network (Alpha blending)
        5. Residual Feature Integration
        6. Layer Normalization
    """

    def __init__(self, visual_dim=768, pose_dim=59, fusion_dim=256, num_heads=4, dropout=0.1):
        super(PGCMAFLayer, self).__init__()
        self.fusion_dim = fusion_dim
        
        # 1. Projections into shared latent space
        self.vis_proj = nn.Sequential(
            nn.Linear(visual_dim, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )
        
        self.pose_proj = nn.Sequential(
            nn.Linear(pose_dim, fusion_dim),
            nn.LayerNorm(fusion_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )
        
        # 2. Pose-guided attention
        self.cross_attn = PoseGuidedCrossModalAttention(
            d_model=fusion_dim,
            n_heads=num_heads,
            dropout=dropout
        )
        
        # 3. Adaptive Gating Network
        self.gate_net = nn.Sequential(
            nn.Linear(fusion_dim * 2, fusion_dim),
            nn.Sigmoid()
        )
        
        # 4. Residual Integration and LayerNorm
        self.layer_norm = nn.LayerNorm(fusion_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, visual_feats, pose_feats):
        """
        Forward Pass for PG-CMAF.
        Args:
            visual_feats: (B, visual_dim) or (B, T, visual_dim)
            pose_feats: (B, pose_dim) or (B, T, pose_dim)
        Returns:
            fused_rep: (B, fusion_dim) or (B, T, fusion_dim)
            attn_weights: Attention maps for interpretability
            gate_values: Gating coefficients for multi-modal contribution analysis
        """
        # Linear projections
        v_proj = self.vis_proj(visual_feats)   # (B, T, D) or (B, D)
        p_proj = self.pose_proj(pose_feats)   # (B, T, D) or (B, D)
        
        # Match dimensions if one is 2D and other is 3D
        if v_proj.dim() == 2 and p_proj.dim() == 3:
            v_proj = v_proj.unsqueeze(1).expand(-1, p_proj.size(1), -1)
        elif p_proj.dim() == 2 and v_proj.dim() == 3:
            p_proj = p_proj.unsqueeze(1).expand(-1, v_proj.size(1), -1)
            
        # Pose queries visual representation
        attn_out, attn_weights = self.cross_attn(p_proj, v_proj)
        
        # Adaptive gating
        gate_input = torch.cat([p_proj, attn_out], dim=-1)
        alpha = self.gate_net(gate_input)  # Gating weights in [0, 1]
        
        # Adaptively blend pose guidance and attended visual information
        guided_feat = alpha * attn_out + (1.0 - alpha) * p_proj
        
        # Residual connection with visual features and Layer Normalization
        fused = self.layer_norm(v_proj + self.dropout(guided_feat))
        
        return fused, attn_weights, alpha


class MultiModalFusionComparison(nn.Module):
    """
    Unified module for Ablation & Comparative Analysis across 4 Fusion Configurations:
        - visual_only: VideoMAE features only
        - pose_only: RTMPose skeletal features only
        - concat: Simple feature concatenation + Linear MLP
        - pg_cmaf: Proposed Pose-Guided Cross-Modal Attention Fusion
    """

    def __init__(self, visual_dim=768, pose_dim=59, fusion_dim=256, mode="pg_cmaf"):
        super(MultiModalFusionComparison, self).__init__()
        self.mode = mode
        self.fusion_dim = fusion_dim
        
        if mode == "visual_only":
            self.model = nn.Sequential(
                nn.Linear(visual_dim, fusion_dim),
                nn.LayerNorm(fusion_dim),
                nn.GELU()
            )
        elif mode == "pose_only":
            self.model = nn.Sequential(
                nn.Linear(pose_dim, fusion_dim),
                nn.LayerNorm(fusion_dim),
                nn.GELU()
            )
        elif mode in ["concat", "cross_attn_no_pose_guide"]:
            self.model = nn.Sequential(
                nn.Linear(visual_dim + pose_dim, fusion_dim),
                nn.LayerNorm(fusion_dim),
                nn.GELU()
            )
        elif mode == "pg_cmaf":
            self.model = PGCMAFLayer(visual_dim=visual_dim, pose_dim=pose_dim, fusion_dim=fusion_dim)
        else:
            raise ValueError(f"Unknown fusion mode: {mode}")

    def forward(self, visual_feats, pose_feats):
        if self.mode == "visual_only":
            return self.model(visual_feats), None, None
        elif self.mode == "pose_only":
            return self.model(pose_feats), None, None
        elif self.mode in ["concat", "cross_attn_no_pose_guide"]:
            # Ensure compatible dimensionality for concatenation
            if visual_feats.dim() == 2 and pose_feats.dim() == 3:
                visual_feats = visual_feats.unsqueeze(1).expand(-1, pose_feats.size(1), -1)
            elif pose_feats.dim() == 2 and visual_feats.dim() == 3:
                pose_feats = pose_feats.unsqueeze(1).expand(-1, visual_feats.size(1), -1)
            combined = torch.cat([visual_feats, pose_feats], dim=-1)
            return self.model(combined), None, None
        elif self.mode == "pg_cmaf":
            return self.model(visual_feats, pose_feats)
