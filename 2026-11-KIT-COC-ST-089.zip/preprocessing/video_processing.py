"""
Module 2: Video Loading, Frame Sampling, Augmentation, and Split Management
Ensures subject/video-level separation between train, val, and test splits to prevent data leakage.
"""

import os
import cv2
import numpy as np
import logging
import torch
import torchvision.transforms as T
from PIL import Image

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class VideoPreprocessor:
    """
    Handles OpenCV video loading, uniform temporal sampling, resizing,
    spatial/temporal augmentations, and tensor normalization.
    """

    def __init__(self, clip_len=16, frame_size=(224, 224), fps=15):
        self.clip_len = clip_len
        self.frame_size = frame_size
        self.fps = fps
        
        # ImageNet normalization standard for VideoMAE
        self.mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        self.std = np.array([0.229, 0.224, 0.225], dtype=np.float32)

    def load_video_frames(self, video_path):
        """
        Load all frames from a video file using OpenCV.
        Handles missing or corrupted files gracefully.
        """
        if not os.path.exists(video_path):
            logger.warning(f"Video file not found: {video_path}")
            return None
            
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            logger.warning(f"Unable to open video stream: {video_path}")
            return None
            
        frames = []
        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                break
            # Convert BGR to RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frames.append(frame_rgb)
            
        cap.release()
        return frames

    def sample_frames(self, frames, is_training=False):
        """
        Uniformly sample a fixed sequence of `clip_len` frames.
        Handles variable length and short clips with boundary padding.
        """
        total_frames = len(frames)
        if total_frames == 0:
            return np.zeros((self.clip_len, self.frame_size[0], self.frame_size[1], 3), dtype=np.float32)
            
        if total_frames < self.clip_len:
            # Repeat last frame to satisfy clip_len
            indices = np.linspace(0, total_frames - 1, self.clip_len, dtype=int)
        else:
            if is_training:
                # Stochastic temporal jitter during training
                stride = max(1, total_frames // self.clip_len)
                max_start = max(0, total_frames - self.clip_len * stride)
                start_idx = np.random.randint(0, max_start + 1) if max_start > 0 else 0
                indices = np.clip(start_idx + np.arange(self.clip_len) * stride, 0, total_frames - 1)
            else:
                # Deterministic uniform sampling for evaluation/testing
                indices = np.linspace(0, total_frames - 1, self.clip_len, dtype=int)
                
        sampled_frames = [frames[i] for i in indices]
        return sampled_frames

    def preprocess_sequence(self, sampled_frames, is_training=False):
        """
        Resize, apply data augmentations if training, and normalize.
        Returns a float32 numpy array of shape (T, H, W, C) normalized to [0, 1] then standardized.
        """
        processed_frames = []
        
        # Consistent random parameters across all frames in a clip
        do_flip = is_training and (np.random.rand() > 0.5)
        brightness_factor = 1.0 + (np.random.uniform(-0.15, 0.15) if is_training else 0.0)
        
        for frame in sampled_frames:
            # Resize
            resized = cv2.resize(frame, (self.frame_size[1], self.frame_size[0]), interpolation=cv2.INTER_LINEAR)
            
            # Augmentation
            if do_flip:
                resized = cv2.flip(resized, 1)
                
            frame_float = resized.astype(np.float32) / 255.0
            if is_training:
                frame_float = np.clip(frame_float * brightness_factor, 0.0, 1.0)
                
            # Normalize
            norm_frame = (frame_float - self.mean) / self.std
            processed_frames.append(norm_frame)
            
        return np.array(processed_frames, dtype=np.float32)

    def process_video_file(self, video_path, is_training=False):
        """
        Complete end-to-end preprocessing pipeline for a video file.
        Returns tensor of shape (C, T, H, W) for PyTorch VideoMAE or (T, H, W, C) numpy array.
        """
        raw_frames = self.load_video_frames(video_path)
        if raw_frames is None or len(raw_frames) == 0:
            return None, None
            
        sampled_raw = self.sample_frames(raw_frames, is_training=False)
        processed_clip = self.preprocess_sequence(sampled_raw, is_training=is_training)
        
        # Convert to PyTorch format (C, T, H, W)
        tensor_clip = torch.from_numpy(processed_clip).permute(3, 0, 1, 2).contiguous()
        return tensor_clip, sampled_raw


def create_synthetic_sports_video(output_path, sport="basketball", is_positive=True, num_frames=30, size=(320, 240)):
    """
    Generates realistic synthetic sports execution video files for reference and athlete testing,
    ensuring actual OpenCV decoding, RTMPose keypoint extraction, and deep learning video inference.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, 15, size)
    
    w, h = size
    cx = w // 2
    base_y = int(h * 0.75)
    
    # Biomechanical trajectory curves based on sport and positive/negative execution
    for t in range(num_frames):
        img = np.zeros((h, w, 3), dtype=np.uint8)
        # Background: sports court or field
        if sport in ["basketball", "weightlifting", "aerobics"]:
            # Gym floor / court
            img[:] = (35, 45, 60)
            cv2.line(img, (0, int(h * 0.8)), (w, int(h * 0.8)), (60, 80, 110), 2)
        elif sport in ["soccer", "rock_climbing"]:
            # Turf / outdoor
            img[:] = (40, 75, 40)
            cv2.line(img, (0, int(h * 0.8)), (w, int(h * 0.8)), (200, 200, 200), 2)
        else:
            # Tennis court
            img[:] = (45, 55, 90)
            cv2.line(img, (0, int(h * 0.8)), (w, int(h * 0.8)), (220, 220, 220), 2)
            
        phase = t / float(num_frames)
        
        # Biomechanical motion kinematics
        if sport == "basketball":
            # Jump shot: dip, jump, release
            jump_y = int(np.sin(phase * np.pi) * 35) if is_positive else int(np.sin(phase * np.pi) * 15)
            torso_y = base_y - 65 - jump_y
            arm_reach = int(phase * 40)
            head_pos = (cx, torso_y - 35)
            cv2.circle(img, head_pos, 12, (200, 180, 150), -1)
            cv2.line(img, head_pos, (cx, torso_y + 20), (220, 100, 50), 4)  # Torso
            # Arms & Basketball
            cv2.line(img, (cx, torso_y - 15), (cx + 15, torso_y - 25 - arm_reach), (200, 180, 150), 3)
            ball_pos = (cx + 18, torso_y - 35 - arm_reach)
            cv2.circle(img, ball_pos, 9, (20, 120, 240), -1)  # Ball
            # Legs
            cv2.line(img, (cx, torso_y + 20), (cx - 15, base_y - jump_y), (180, 160, 130), 4)
            cv2.line(img, (cx, torso_y + 20), (cx + 15, base_y - jump_y), (180, 160, 130), 4)
            
        elif sport == "soccer":
            # Kicking motion: approach, plant, strike, follow-through
            lean = int(np.sin(phase * np.pi) * 12) if is_positive else 0
            kick_x = int(np.sin(phase * np.pi) * 30)
            head_pos = (cx - 20 + lean, base_y - 80)
            cv2.circle(img, head_pos, 12, (200, 180, 150), -1)
            cv2.line(img, head_pos, (cx - 15, base_y - 30), (50, 180, 100), 4)
            cv2.line(img, (cx - 15, base_y - 30), (cx - 25, base_y), (180, 160, 130), 4) # Plant foot
            cv2.line(img, (cx - 15, base_y - 30), (cx + kick_x, base_y - 5), (180, 160, 130), 4) # Kicking foot
            ball_x = cx + 10 + (int(phase * 60) if phase > 0.6 else 0)
            cv2.circle(img, (ball_x, base_y - 6), 8, (240, 240, 240), -1)
            
        elif sport == "weightlifting":
            # Squat / Clean & Jerk: descent and ascent
            depth = int(np.sin(phase * np.pi) * 30) if is_positive else int(np.sin(phase * np.pi) * 14) # Incomplete depth if negative
            head_pos = (cx, base_y - 85 + depth)
            cv2.circle(img, head_pos, 12, (200, 180, 150), -1)
            cv2.line(img, head_pos, (cx, base_y - 35 + depth), (100, 100, 220), 4)
            # Barbell across shoulders
            cv2.line(img, (cx - 45, head_pos[1] + 12), (cx + 45, head_pos[1] + 12), (180, 180, 180), 3)
            cv2.circle(img, (cx - 45, head_pos[1] + 12), 10, (50, 50, 50), -1)
            cv2.circle(img, (cx + 45, head_pos[1] + 12), 10, (50, 50, 50), -1)
            # Knees and legs
            cv2.line(img, (cx, base_y - 35 + depth), (cx - 20, base_y - 15 + depth//2), (180, 160, 130), 4)
            cv2.line(img, (cx - 20, base_y - 15 + depth//2), (cx - 25, base_y), (180, 160, 130), 4)
            cv2.line(img, (cx, base_y - 35 + depth), (cx + 20, base_y - 15 + depth//2), (180, 160, 130), 4)
            cv2.line(img, (cx + 20, base_y - 15 + depth//2), (cx + 25, base_y), (180, 160, 130), 4)
            
        else:
            # General athletic motion (Tennis/Aerobics/Rock Climbing)
            sway = int(np.sin(phase * 2 * np.pi) * (20 if is_positive else 8))
            head_pos = (cx + sway, base_y - 80)
            cv2.circle(img, head_pos, 12, (200, 180, 150), -1)
            cv2.line(img, head_pos, (cx + sway, base_y - 30), (180, 140, 60), 4)
            cv2.line(img, (cx + sway, base_y - 30), (cx - 15, base_y), (180, 160, 130), 4)
            cv2.line(img, (cx + sway, base_y - 30), (cx + 15, base_y), (180, 160, 130), 4)
            cv2.line(img, (cx + sway, base_y - 65), (cx + sway + 25, base_y - 75), (200, 180, 150), 3)

        # Overlay video frame metadata
        cv2.putText(img, f"{sport.upper()} - {'POS' if is_positive else 'NEG'}", (10, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        out.write(img)
        
    out.release()
    return output_path


def split_dataset_by_video_id(df_records, train_ratio=0.70, val_ratio=0.15, test_ratio=0.15, random_seed=42):
    """
    Splits the dataset strictly by unique video_id to eliminate data leakage.
    No frame or shot from a video in the test set will ever appear in train/val sets.
    """
    np.random.seed(random_seed)
    unique_videos = df_records['video_id'].unique()
    np.random.shuffle(unique_videos)
    
    n_total = len(unique_videos)
    n_train = int(n_total * train_ratio)
    n_val = int(n_total * val_ratio)
    
    train_vids = set(unique_videos[:n_train])
    val_vids = set(unique_videos[n_train:n_train + n_val])
    test_vids = set(unique_videos[n_train + n_val:])
    
    train_df = df_records[df_records['video_id'].isin(train_vids)].copy()
    val_df = df_records[df_records['video_id'].isin(val_vids)].copy()
    test_df = df_records[df_records['video_id'].isin(test_vids)].copy()
    
    train_df['split'] = 'train'
    val_df['split'] = 'val'
    test_df['split'] = 'test'
    
    logger.info(f"Leakage-free video-level split: Train={len(train_vids)} vids ({len(train_df)} samples), "
                f"Val={len(val_vids)} vids ({len(val_df)} samples), "
                f"Test={len(test_vids)} vids ({len(test_df)} samples)")
                
    return train_df, val_df, test_df

