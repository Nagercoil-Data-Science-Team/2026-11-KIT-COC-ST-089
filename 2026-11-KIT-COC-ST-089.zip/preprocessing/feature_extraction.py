"""
Module 4 (Pipeline): Spatiotemporal Feature Extraction Pipeline
Combines OpenCV video sampling, VideoMAE feature extraction, and saves representations.
"""

import os
import torch
import numpy as np
import logging
from Sports_Skill_Evaluation.models.videomae import VideoMAEFeatureExtractor
from Sports_Skill_Evaluation.preprocessing.video_processing import VideoPreprocessor

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def extract_features_for_dataset(video_paths_dict, output_dir, device="cpu", batch_size=4):
    """
    Extracts VideoMAE spatiotemporal embeddings for video files.
    Saves:
        {output_dir}/{video_id}_visual.npy: shape (768,)
        {output_dir}/{video_id}_frames.npy: shape (16, 768)
    """
    os.makedirs(output_dir, exist_ok=True)
    preprocessor = VideoPreprocessor(clip_len=16, frame_size=(224, 224))
    extractor = VideoMAEFeatureExtractor(device=device)
    
    extracted_records = {}
    video_items = list(video_paths_dict.items())
    
    for i in range(0, len(video_items), batch_size):
        batch = video_items[i:i + batch_size]
        batch_tensors = []
        valid_vids = []
        
        for vid_id, vid_path in batch:
            if not os.path.exists(vid_path):
                continue
            tensor_clip, _ = preprocessor.process_video_file(vid_path, is_training=False)
            if tensor_clip is not None:
                batch_tensors.append(tensor_clip)
                valid_vids.append(vid_id)
                
        if len(batch_tensors) == 0:
            continue
            
        stacked_batch = torch.stack(batch_tensors, dim=0) # (B, C, T, H, W)
        video_embeds, frame_embeds = extractor(stacked_batch)
        
        v_np = video_embeds.cpu().numpy()
        f_np = frame_embeds.cpu().numpy()
        
        for idx, vid_id in enumerate(valid_vids):
            v_save = os.path.join(output_dir, f"{vid_id}_visual.npy")
            f_save = os.path.join(output_dir, f"{vid_id}_frames.npy")
            
            np.save(v_save, v_np[idx])
            np.save(f_save, f_np[idx])
            
            extracted_records[vid_id] = {
                "visual_embed_path": v_save,
                "frames_embed_path": f_save,
                "feature_dim": v_np[idx].shape
            }
            
    logger.info(f"VideoMAE extracted features for {len(extracted_records)} videos.")
    return extracted_records

