"""
Module 3 (Pipeline): Batch Pose Extraction and Skeletal Sequence Persistence
"""

import os
import cv2
import numpy as np
import logging
from Sports_Skill_Evaluation.models.rtmpose import RTMPoseExtractor

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


def extract_poses_for_dataset(video_paths_dict, output_dir, device="cpu"):
    """
    Extracts skeletal keypoint sequences for a dictionary of {video_id: video_file_path}.
    Saves:
        {output_dir}/{video_id}_pose.npy: shape (T, 59)
        {output_dir}/{video_id}_kpts.npy: shape (T, 17, 3)
    """
    os.makedirs(output_dir, exist_ok=True)
    extractor = RTMPoseExtractor(device=device)
    
    extracted_records = {}
    for vid_id, vid_path in video_paths_dict.items():
        if not os.path.exists(vid_path):
            continue
            
        cap = cv2.VideoCapture(vid_path)
        frames = []
        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                break
            frames.append(frame)
        cap.release()
        
        if len(frames) == 0:
            continue
            
        kpts_seq, angles_seq, traj_seq = extractor.extract_sequence_pose(frames)
        skel_feats = extractor.compile_skeletal_representation(kpts_seq, angles_seq)
        
        pose_save_path = os.path.join(output_dir, f"{vid_id}_pose.npy")
        kpts_save_path = os.path.join(output_dir, f"{vid_id}_kpts.npy")
        
        np.save(pose_save_path, skel_feats)
        np.save(kpts_save_path, kpts_seq)
        
        extracted_records[vid_id] = {
            "pose_path": pose_save_path,
            "kpts_path": kpts_save_path,
            "frames_analyzed": len(frames),
            "skeletal_feature_dim": skel_feats.shape
        }
        
    logger.info(f"Successfully extracted skeletal pose representations for {len(extracted_records)} videos.")
    return extracted_records

